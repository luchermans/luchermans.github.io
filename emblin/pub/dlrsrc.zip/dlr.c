/************************************************************************
	Copyright (C) 2002 by DoBiT nv

             All Rights Reserved

Permission to use, copy, modify, and distribute this software and its
documentation for any purpose and without fee is hereby granted, provided
that the above copyright notice appear in all copies and that both that
copyright notice and this permission notice appear in supporting
documentation, and that the name of DoBiT nv not be used
in advertising or publicity pertaining to distribution of the software
without specific, written prior permission.

DOBIT NV DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE,
INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS.
IN NO EVENT SHALL DOBIT BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS
ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF
THIS SOFTWARE.
************************************************************************/

/* START LIBRARY DESCRIPTION ********************************************
DLR.C
	*** DOWNLOAD AND RUN ***
	Copyright (C) 2002 by DoBit nv
WARNING:
	THIS PROGRAM IS PROVIDED AS A SAMPLE ONLY!
	!!!! It could overwrite the SysIDBlock !!!!
VERSION_HISTORY:
	1.00 22-11-2002	First release RCM2200-2250 DC_7.21SE
	1.01 31-03-2004 First try with DC_8.51
	1.02 15-04-2004 OK with RCM3700 DC_8.30 and 8.51
AUTHOR:
	Luc Hermans <mailto:smultita@dobit.com>
	More info <http://www.dobit.com/emblin/dlr.htm>
DESCRIPTION:
    Download a PROGRAM via TFTP to FLASH or RAM then RUN this prog

    This program illustrates HOWTO
    1. Download a program.bin (that was compiled to RAM) to RAM and run it.
    2. Program your flash from a program compiled to (and running in) RAM.
    3. Read the UserBLock from a program compiled to (and running in) RAM.
    4. Use BOOTP (DHCP-TFTP) and RUN the BOOTPFILE.

    If DLR.C is COMPILED to FLASH then dlr_tfpt( )
	Will download a FILE DOWNLOAD.BIN via tftp and write it in RAM 0x80000
	and run this code in RAM at 0x80000.
	DOWNLOAD.BIN should be a program.bin that was compiled to RAM.
    If DLR.C is COMPILED to RAM then dlr_tftp( )
	Will download a FILE PROGRAM.BIN via tftp and write this to the FLASH
	(which is mapped to BANK 1 or 3) and run the new code in FLASH.
	PROGRAM.BIN should be a program.bin that was compiled to FLASH.
    If (you USE_DHCP) Then
        File and TFTPserver should be set in your DHCPserver
    Else use the default SRV_IP_ADDRESS
        If running/compiled to RAM   Then file=PROGRAM.BIN
        If running/compiled to FLASH Then file=DOWNLOAD.BIN
	You can path the BIN files IPaddr/file using a hex editor

    In my main project I use static IPaddr (saved in UserBlock)
    If I want to upgrade the firmware I just call dlr_tftp()
    This will download the file /DOWNLOAD.BIN via TFTP, where DOWNLOAD.BIN
    is this program compiled to RAM. Then running DOWNLOAD.BIN
    will download and program PROGRAM.BIN to FLASH, which is my new firmware.

    I use PUMPKIN TFTP found at <http://www.klever.net/kin/pumpkin.html>
    and put the files DOWNLOAD.BIN and PROGRAM.BIN in the TFTP rootdir
    giving everyone read access.

PATCHES:
    Some small patches (see below) has to be done to make it work
REMARKS:
    - To create a compiled to RAM .BIN file with DC 8.xx
      select Project Options, Compiler and set:
         - Code and BIOS in RAM
         - Compile defined target config to .bin file
      Then select Compile, Compile or press F5.
    - If you use TFTPD32 <http://tftpd32.jounin.net/> select Settings:
      translate UNIX filenames and Allow "\" as virtual root
    - You can use this as a library by adding folowing 2 lines to your source
	#define DLR_LIB
	#use "dlr.c"

END DESCRIPTION**********************************************************/

/*line---- XMEM.LIB patch WriteFlash() if running in RAM --- ------------only DC 7.xx
line ins=Insert  lav=leaveAsIs  mov=MoveFromLine
529  mov	if((unsigned)rootSrc >= 0xe000u || ...	//this check
530  mov		retval = -2;			//is ok
     ins	#ifndef FLASH_IS_AT_BANK  //if FLASH_IS_AT_BANK then remove
527  lav		if(flashDst >= (RAM_START<<12ul) || ...	this check
533  lav		if ((SysIDBlock.idBlockSize ...	    and this check ?!
     ins	#endif
---------------------------------------------------------------------------*/
/*line---- IDBLOCK.LIB patch readUserBlock() if running in RAM ----------only DC 7.xx
line ins=Insert  lav=LeaveAsIs
     ins	#ifdef FLASH_IS_AT_BANK
     ins		physaddr = physaddr + (FLASH_IS_AT_BANK<<18UL);
     ins	#endif
687  lav	xmem2root(dest, physaddr, numbytes);
----------------------------------------------------------------------------*/
/*line ---- BOOTP.LIB patch if you want BOOTP----------------------------only DC 7.xx
line ins=Insert
682  ins	#ifdef BOOTP_FILE
     ins	   strcpy( BOOTP_FILE, parms->bootfile);
     ins	#endif
----------------------------------------------------------------------------*/
/*line ---- TFTP.LIB patch error DHCP_ST_PERMANENT-----------------------only DC 8.30
rename USE_DHCP into TFTP_USE_DHCP in this lib
----------------------------------------------------------------------------*/
/*line ---- TFTP.LIB patch error DHCP_ST_PERMANENT-----------------------only DC 8.51
314  rem	if(udp_waitopen(ts->sock, IF_ANY, ...
     ins	if(!udp_open(ts->sock, ts->my_tid, ts->rem_ip, 0, NULL))
----------------------------------------------------------------------------*/
/*line ---- TFTP.LIB patch for download file > 64KB ----------------------all DC x.xx
line rpl=Replace  rem=Remark  lav=LeaveAsIs
100  rpl	long	buf_len;	// long instead of word
101  rpl	long	buf_used;	// long instead of word
     lav   case TFTP_OP_DATA:  find a bit below
373  rem	//newlen = ts->buf_used + (word)len;	// Total length of data obtained
374  rpl	if ( (ts->buf_used + len) > ts->buf_len)	{ // Buffer overflow?
375  rpl		len = (int)(ts->buf_len - ts->buf_used);
604  rpl	int tftp_exec( char put, long buf_addr, long * len, int mode,
----------------------------------------------------------------------------*/
/*line ---- TFTP.LIB patch for FlashWrite ---------------------------------all DC x.xx
line ins=Insert  rpl=Replace
80   ins	#ifndef	root2dst
     ins	   #define root2dst(_dst,_src,_len)   root2xmem((_dst),(_src),(_len))
     ins	#endif
     lav   case TFTP_OP_DATA:  find a bit below
     lav	if (len > 0 ) {
379  rpl		root2dst(	//replacement for root2xmem(
----------------------------------------------------------------------------*/

/*** BeginHeader */
#ifndef DLR_LIB

#define USE_DHCP		//--remark for STATIC_IP
//#define TFTP_DEBUG		//--remark to disable debugging
#ifndef	TFTP_DEBUG
	#nodebug
#endif

#define MY_IP_ADDRESS	"10.204.204.215"	//if you use static IP you can
#define MY_NETMASK	"255.255.255.0"		//patch the file.BIN with other
#define SRV_IP_ADDRESS	"10.204.204.182"	//IP's and FILE_2_DOWNLOAD

#define STDIO_DISABLE_FLOATS			//--who needs float ?

#ifdef _RAM_
  #define FLASH_IS_AT_BANK	3	//BANK1 or 3
  #if _FLASH_SIZE_ == 0x80		//INVERT A18 to map 1st half of Flash in BANK 3
    #define DLR_MB3CR_SETTING	FLASH_WSTATES | CS_FLASH | 0x10
  #else
    #define DLR_MB3CR_SETTING	FLASH_WSTATES | CS_FLASH
  #endif
  #define FILE_2_DOWNLOAD	"/PROGRAM.BIN"
  #define root2dst(_dst,_src,_len)	WriteFlashB((_dst),(_src),(_len))
  #define TFTP_ADDR	(FLASH_IS_AT_BANK<<18UL)
  #define TFTP_MAXLEN	0x3c000UL
#else
  #undef  FLASH_IS_AT_BANK
  #define FILE_2_DOWNLOAD	"/DOWNLOAD.BIN"
  #define root2dst(_dst,_src,_len)	root2xmem((_dst),(_src),(_len))
  #define TFTP_ADDR	0x80000UL
  #define TFTP_MAXLEN	0x2ffffUL
#endif

#define TFTP_TIMEOUT		1000	//--strange but 750 doesn't work with PumpKIN Tftp
#define TFTP_RETRIES		4
//#define TFTP_ALLOW_BUG		//--Don't use bugy software
#define	TFTP_DISABLE_WRITE	1	//--I also have disabled TFTP WRITE to keep code small
#define	TFTP_HIT_WDOG(_wd)		VdHitWd(_wd);

#define	MAX_TCP_SOCKET_BUFFERS	0	//--disable tcp buffers
#define ETH_MAXBUFS     	2	//--reduce mem usage (default 10)
#define	UDP_BUF_SIZE 		640	//--just enough for tftp (xalloc)
#define DISABLE_DNS	1		// No need for DNS
#define DISABLE_TCP	1		// Do not require TCP functions
#define DISABLE_ARP	1		// Use simple ARP

#ifndef USE_DHCP
  #define MAX_UDP_SOCKET_BUFFERS 1	//--only one needed for TFTP
#else //---- USE_DHCP -----
  #define MAX_UDP_SOCKET_BUFFERS 2	//--need extra UDP buffer for DHCP
  #define DHCP_MINRETRY		5
//#define BOOTP_VERBOSE
//#define BOOTP_DEBUG
//#define DHCP_CLIENT_ID_MAC
//#define DHCP_CLASS_ID "Rabbit-TCPIP:Z-World:DHCP-Test:1.2.0"
//#define BOOTP_ONLY
  #if (CC_VER>>8) > 7)	//----DC_8.xx
	#define USE_IF_CALLBACK	1	// to get BOOTP_FILE see opt_callback()
	#define DLR_BOOTP_HOST	_dhcp_info[IF_DEFAULT].bootp_host
	#define DLR_DHCP_HOST	_dhcp_info[IF_DEFAULT].dhcp_server
  #else			//----DC_7.xx
	#warnt "Modify BOOTP.LIB for download and run"
      #ifdef _RAM_
	#warnt "You must modify WriteFlash() in XMEM.LIB"
	#warnt "If you need readUserBlock() also modify IDBLOCK.LIB"
      #endif
	#define BOOTP_FILE	_bootpfile
	#define DLR_BOOTP_HOST	_bootphost
	#define DLR_DHCP_HOST	_dhcphost
  #endif
#endif

#if ((TFTP_MAXLEN>>16UL) > 0)
	#warnt "Modify TFTP.LIB for downloads >64KB"
#endif

//#memmap xmem
#use "dcrtcp.lib"
#use "tftp.lib"

#endif //#ifndef DLR_LIB
/*** EndHeader */

/************************************************************************/
/*********************** T F T P ****************************************/
/************************************************************************/
/*** BeginHeader */
#ifdef	TFTP_DEBUG
    #define _dlr_tftp_debug	debug root
#else
    #define _dlr_tftp_debug	nodebug root
#endif
/*** EndHeader */

/*** BeginHeader dlr_run, _map_jump2_zero */
int dlr_run(void);
void _map_jump2_zero(void);
/*** EndHeader */

static char _bootpfile[128];
#define	jump2_Zero	_bootpfile

#asm root nodebug
_map_jump2_zero::  //--this must run in RAM at phy addr above 0x80000 (BANK 2 or 3)
#ifdef _RAM_			//let the watchdog generate a timeout
	ld 	a, RAM_WSTATES | CS_RAM		//map RAM to 0xc0000 BANK 3
	ioi 	ld (MB3CR),a
	ld 	a, FLASH_WSTATES | CS_FLASH	//map FLASH to 0x00000 BANK 0 and 1
#else
	ipset 3			// turn off interrupts
	ld   a,0x51 		// Silence the watchdog.
	ioi  ld (WDTTR),a
	ld   a,0x54
	ioi  ld (WDTTR),a
	ld 	a, RAM_WSTATES | CS_RAM		//map RAM to 0x00000 BANK 0 and 1
#endif
	ld hl, 0xB000		// These two lines get you around a stack bug
	ld sp, hl		// in programs meant for "Run in RAM"
	ioi 	ld (MB1CR),a            //FLASH/RAM now mapped to BANK 0 and 1
	ioi 	ld (MB0CR),a		//          phisical addr 0x00000
	jp	0			//start FLASH/RAM compiled program
_end_jump2_zero::
#endasm

_dlr_tftp_debug
int dlr_run(void)
{
//static char jump2_Zero[32];	//--re_use _bootpfile[128]
  #ifdef __SEPARATE_INST_DATA__
   #if __SEPARATE_INST_DATA__	//--never tested
	xmem2xmem( paddrDS(jump2_Zero), (unsigned long)_map_jump2_zero,  ((int) ((unsigned)_end_jump2_zero - (unsigned)_map_jump2_zero) +1 ) );
	#asm
		ld	hl, jump2_Zero		//from DLM_SERIAL_2_FLASH .C
		lcall	_CallRAMFunction
	#endasm
	#define SEPARATE_USED
   #endif
  #endif
  #ifndef SEPARATE_USED
	memcpy( jump2_Zero, _map_jump2_zero, ((int) ((unsigned)_end_jump2_zero - (unsigned)_map_jump2_zero) +1 ) );
	#asm		//--below does not work with prog cable connected !!
	  	call jump2_Zero
	#endasm
  #endif
//#endif
}

/*** BeginHeader dlr_tftp  */
int dlr_tftp(longword srv_ip, char *fname, int wdog);
/*** EndHeader */

_dlr_tftp_debug
int dlr_tftp(longword srv_ip, char *fname, int wdog)
{  auto udp_Socket sck;
   auto struct tftp_state ts;
   auto int r;
	ts.buf_len = TFTP_MAXLEN;	//--!!modify TFTP.LIB for files >64Kb
	ts.buf_addr = TFTP_ADDR;	//--physical addr start of FLASH/RAM
	ts.state = 0;			// 0 = read
  	ts.my_tid = 0;			// zero to use default TFTP UDP port number
	ts.buf_used=0;
	ts.sock = &sck;			// point to socket to use
  	ts.rem_ip = srv_ip;		// resolve server IP address
  	ts.mode = TFTP_MODE_OCTET;	// send/receive binary data
   #ifdef mTFTP_LIB
  	ts.file=fname;	// this is only for my mtftp.lib
   #else
	strcpy(ts.file, fname);		// set file name on server
   #endif
#ifdef	TFTP_DEBUG
   #ifdef _RAM_
	printf("\nTftp PhyAddr = %08LX programming Flash...\n", ts.buf_addr);
   #else
   	printf("\nTftp PhyAddr = %08LX download to RAM...\n", ts.buf_addr);
   #endif
#endif
	tftp_init(&ts);
	while ( (r=tftp_tick(&ts)) > 0)		// Loop until complete
		TFTP_HIT_WDOG(wdog);
#ifdef	TFTP_DEBUG
	printf("Tfpt Done Rslt=%d Len=%ld", r, (long)ts.buf_used);
	#warnt "PUT A BREAK-POINT BELOW"
#endif
	if (r==0)  dlr_run();	//run the program
	return r;
}
/*** BeginHeader WriteFlashB  */
int WriteFlashB(unsigned long flashDst, void* rootSrc, int len);
/*** EndHeader */

//------ flash write ... replacement for root2xmem() in tftp.lib ------
#ifdef	_RAM_	//---only if running in RAM
_dlr_tftp_debug
int WriteFlashB(unsigned long flashDst, void* rootSrc, int len)
{ auto long delms;
	delms=MS_TIMER+20; while (MS_TIMER<delms);	//---just add 20 ms pause
	return WriteFlash(flashDst, rootSrc, len);
}
#endif

/*** BeginHeader */
#ifndef DLR_LIB
/*** EndHeader */

/***************************************************************************
// Callback for handling customized DHCP options. (see samples/DHCP_BOOTFILE.C)
// We use this function to grab the bootfile name.
// This is recognized when the 'opt' parameter is 0.
***************************************************************************/
#ifdef USE_IF_CALLBACK
int opt_callback(int iface, DHCPInfo * di, int opt, int len, char * data)
{
 #ifdef	TFTP_DEBUG
   printf("opt_callback: got option %d, length %d on i/f %d\n", opt, len, iface);
 #endif
   if (opt == 0)
   {  memcpy(_bootpfile, data, 128);
      _bootpfile[127]=0;
   }
   return 0;
}
#endif //USE_IF_CALLBACK
/************************************************************************/
/*********************** M A I N ****************************************/
/************************************************************************/
void main(void)
{ int wdog;
  int r;
  longword srv_ip;
  long tm;
  char *boot_file;

#ifdef _RAM_    //----------Map FLASH to BANK  !! use the right MBRxShadow !!
	WrPortI(MB0CR+FLASH_IS_AT_BANK, &MB3CRShadow, DLR_MB3CR_SETTING);
	//because MAC_addr is (for non REALTEK) in sys_id_block this must be called before TCP/IP init
	_readIDBlock(1<<FLASH_IS_AT_BANK); //hope this makes readUserBlock() work from RAM
	_InitFlashDriver(1<<FLASH_IS_AT_BANK);
	//again write to MB3CR to clear Write-Protect Bit (set by _InitFlashDriver)
	WrPortI(MB0CR+FLASH_IS_AT_BANK, &MB3CRShadow, DLR_MB3CR_SETTING);
#endif
	_bootpfile[0]=0;
	wdog=VdGetFreeWd(250);	//--WDog timeout=15 sec
	sock_init();

#ifdef USE_IF_CALLBACK    // Tell it to call the callback when the bootfile option is received...
        #define MY_OPTS  ((char*)&srv_ip)	//re-use for OPTS
	MY_OPTS[0]=0;
	r=ifconfig(IF_DEFAULT, IFS_DHCP_OPTIONS, 1, MY_OPTS, opt_callback,IFS_END);
#endif

	srv_ip=inet_addr(SRV_IP_ADDRESS);
	boot_file=FILE_2_DOWNLOAD;	//default FILE

#ifdef	USE_DHCP
	tm=SEC_TIMER+10;
	while(SEC_TIMER<tm)	//wait until we get an IP-addr (or WDog timeout)
	{	tcp_tick(NULL);
		if (DLR_BOOTP_HOST && my_ip_addr) break;
	}
	TFTP_HIT_WDOG(wdog);

	if (DLR_BOOTP_HOST)		//if we got a bootphost
	{	srv_ip=DLR_BOOTP_HOST;	//set is as our tftp_server, also set the boot_file
	#ifndef _RAM_
		if (_bootpfile[0])	boot_file=_bootpfile;
	#endif
	}
	else if (DLR_DHCP_HOST)		//if no bootphost try dhcphost
		srv_ip=DLR_DHCP_HOST;
	if (my_ip_addr==0)		//if everything fails
		my_ip_addr=inet_addr(MY_IP_ADDRESS);
#endif	//endif USE_DHCP

#ifdef TFTP_DEBUG
	printf("\n myIP_Adr:%08lx   NetMask:%08lx ", my_ip_addr, sin_mask);
	printf("\n TFTP_srv:%08lx  BootFile:%s ", srv_ip, boot_file);
#endif
	//you can put your app here, and if you want to upgrade call dlr_tftp()
	//But I'am going to download the file from srv_ip and run it

	r=dlr_tftp( srv_ip, boot_file, wdog);
#ifdef	USE_DHCP	//if DHCP_BOOTP_SRV fails try the fix SRV_IP_ADDRESS
	srv_ip=inet_addr(SRV_IP_ADDRESS);
	r=dlr_tftp( srv_ip, boot_file, wdog);
#endif
	while(-1);	//if failed then watchdog reset
}
/************************************************************************/

/*** BeginHeader */
#endif //of ifndef DLR_LIB
/*** EndHeader */