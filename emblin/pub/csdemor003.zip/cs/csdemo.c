/* ------sMultiTa:  Small Simple Software MultiTasking ----------------
 * Copyright (C) 2002 Luc Hermans
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * 
 * Luc Hermans <mailto:lhermans@dobit.com>
 * <http://www.dobit.com/emblin/smultita.htm>
 - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
 This is just a (stupid) demo for the soft multitasking cs()
 pls send BUGS (with bugfix) to <mailto:smultita@dobit.com>
  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
 HISTORY:
 2002-11-13 LH for preemtive surround printf by cs_disable cs_enable
 * --------------------------------------------------------------------*/
#memmap root	//just for test - doesn't care
//#nodebug	//enabling this nodebug will crash ???

#define CS_NR_OF_TASK	4	//--maximum nr of tasks (default=8)
#define CS_WAIT			//--remark if you don't want to put a task in wait status
#define CS_WDOG			//--remark if you don't want a software watchdog
//#define CS_DEBUG		//--only if you want it to
//#define CS_PREEMPTIVE		//--make it Pre-Emptive with timerB_isr
#ifdef CS_PREEMPTIVE
  #define CS_ONE_TICK	4	//--switch tasks every 4 cs() calls (default=32)
#endif
#use CS.LIB			//--put CS.LIB in your LIB.DIR

//---- functions called by CS.LIB ------------------------------
//--- called every swith to retrigger the watch dog
_cs void cs_wdog(void)
{	hitwd();	//-- retrigger a hardware wdog here
}
//--- this is called if a task doe's update the Soft wdog
_cs void cs_reboot(char tasknr)
{	printf("\nWDOG TIMEOUT TASK %d\n", tasknr);
	while (-1);	//-- let WDog time out and reset
	exit(1);	//-- or exit if you prefer
}
//--- if all task are waiting we can sleep also (not too long)
_cs void cs_sleep(void)
{ //static int cnt;
	//---put a OS sleep statement here
	//	if ((++cnt & 0x0F )==1)	myPRINTF(".");
}

//---------- some globals --------------------------
#define	STKSIZE	1024
#define	DELAY	((type_TICK)(oneSEC))
#define STOPCNT	8000
type_SP _tSP;		//-- this is global only because its used in task1
char task2STACK[ STKSIZE];	//-- software stack test

type_TASK task1(void);
type_TASK task2(void);
type_TASK task3(void);

#ifdef CS_PREEMPTIVE
   #warnt "PRE-EMPTIVE multitasking enabled! Doe not disable TimerB INTERRUPT in cs_calls"
   #warnt "Functions shared between Tasks should be re-entrant (printf is NOT)"
   #warnt "A Task-switch can occur in the middle of a shared var update (int, string)"
   #warnt "Use semaphores or surround these updates by cs_disable cs_enable." 
   interrupt cs_isr(void)
   {
   #asm nodebug
	ioi	ld a, (TBCSR)	; load B1, B2 interrupt flags (clears flag); this
	xor	a		; clear a
	ioi	ld (TBL1R), a	; set up next B1 match (at timer=0000h)
	ioi	ld (TBM1R), a	; NOTE:  you _need_ to reload the match
	ipres			; restore interrupts
	call	cs
   #endasm
   }
   void timerB_init(void)
   {	SetVectIntern(0x0B, cs_isr);		// set up ISR 
	WrPortI(TBCR, &TBCRShadow, 0x09);	// clock timer B with (perclk/2)/8 and
						//       set interrupt level to 1
	WrPortI(TBL1R, NULL, 0x00);		// set initial match!
	WrPortI(TBM1R, NULL, 0x00);
	WrPortI(TBCSR, &TBCSRShadow, 0x03);	// enable timer B and B1 match interrupts
   }
   void timerB_exit(void)
   {	WrPortI(TBCSR, &TBCSRShadow, 0x00);	// disable timer B and its interrupts
   }
   void myPRINTF( char *s)
   {   	cs_disable();
       	printf( s);
	cs_enable();
   }
   #define CS()
#else
   #define CS()		cs()
   #define timerB_init()
   #define timerB_exit()
   #define myPRINTF	printf
#endif

/************ MAIN CSDEMO.C *****************************************/
void main(void)
{ long cnt;
  type_TICK mytimer;
  
   cnt=0;
   mytimer=0;
   myPRINTF("\n------- s M u l t i T a -----------" \
	  "\n software multitasking simple demo " \
	  "\n----------------------------------");
   cs_init();	//-- main task is task0
   timerB_init();

   RD_SP(_tSP); //-- get current Stack top
   printf("\nTask0 start  STACK=%08lX", (long)_tSP);

   cs_run(1, task1, 1, _tSP-1*STKSIZE);			//WARNING check stack size !!
//   cs_run(2, task2, 1, _tSP-2*STKSIZE);		//Use the Real stack 
   cs_run(2, task2, 1, (type_SP) &task2STACK[STKSIZE-1] );	//or use a Soft stack
   wd_run();	//---start task0 wdog

   while (-1)
   {	if ((++cnt & 0x1F)==1)
		myPRINTF ("0");
	CS();
	if (cnt==500)
	{	myPRINTF("\nTask0 wait   ");
		cs_Wait(oneSEC);
		myPRINTF("\nTask0 wakeup ");
	}
	if (cnt<7000)			//--put cnt<100 to simulate wdog timout
		wd_set(oneSEC*3);	//--retrigger soft wdog	
	if (tm_chk(&mytimer, DELAY))
	{	myPRINTF("\nTimerElapsed ");
		mytimer=0;
	}
	if (cnt>STOPCNT)
		break;
   }
   myPRINTF("\nTask0 all done" \
	  "\n-------------------------------");
   timerB_exit();
   return;
}

type_TASK task1(void)
{ auto long cnt;
   cnt=0;
   myPRINTF("\nTask1 start  ");
   while (-1)
   {	if ((++cnt & 0x1F)==1)	myPRINTF ("1");
		CS();
		if (cnt==1000)
		{	myPRINTF("\nTask1 halt   ");
			cs_Halt(); //halt myself, someone else should continue me
			myPRINTF("\nTask1 cont   ");
		}
		if (cnt==1500)	//--start task3
			cs_run(3, task3, 1, _tSP-3*STKSIZE);
   }
}

#memmap xmem 	//just for test - doesn't care
type_TASK task2(void)
{  long cnt;
   cnt=0;
   myPRINTF("\nTask2 start  ");
   while (-1)
   {	if ((++cnt & 0x1F)==1)	myPRINTF ("2");
		CS();
		if (cnt==750)
		{	myPRINTF("\nTask2 wait   ");
			cs_Wait(oneSEC);
			myPRINTF("\nTask2 wakeup ");
		}
		if (cnt==1500)
			cs_cont(1);	//-- continue task 1
   }
}

type_TASK task3(void)
{ auto long cnt;
   cnt=0;
   myPRINTF("\nTask3 start  ");
   while (-1)
   {	if ((++cnt & 0x1F)==1)		myPRINTF ("3");
		CS();
		if (cnt==250)
		{	myPRINTF("\nTask3 prioty ");
			cs_Priority(2);
		}
		if (cnt==500)
		{	myPRINTF("\nTask3 cancel ");
			cs_Cancel();	//cancel myself
		}
   }
}

/************ end MAIN CSDEMO.C ************************************/
