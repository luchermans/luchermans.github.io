
This PROGRAM is provided AS A SAMPLE ONLY in the hope 
that it will be useful, but WITHOUT ANY WARRANTY; 
without even the implied warranty of MERCHANTABILITY or 
FITNESS FOR A PARTICULAR PURPOSE.

http:www.dobit.com/emblin/dlr.htm

If you want to use static IP address (RCM3700 version only)
you can patch these bin files using an hex editor
Then find and replase the IP address 10.204.204.xxx
